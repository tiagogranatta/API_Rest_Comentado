//Constante que solicitada informações pelo método GET e passa informações método Post
const Atendimento = require('../models/atendimentos')
//Lista os atendimentos
module.exports = app => {
    app.get('/atendimentos', (req, res) => {
        Atendimento.lista(res)
    })
//Lista atendimentos enquanto o valor for igual a id do atendimento
    app.get('/atendimentos/:id', (req, res) => {
        const id = parseInt(req.params.id)

        Atendimento.buscaPorId(id, res)
    })
//Passando paramentos via post bia body-parson
    app.post('/atendimentos', (req, res) => {
       const atendimento = req.body

        Atendimento.adiciona(atendimento, res)
    }) 
//Update de informações requisitando valores, e alterando valores das colunas requisitadas
    app.patch('/atendimentos/:id', (req, res) => {
        const id = parseInt(req.params.id)
        const valores = req.body

        Atendimento.altera(id, valores, res)
    })
//Deletando informações
    app.delete('/atendimentos/:id', (req, res) => {
        const id = parseInt(req.params.id)

        Atendimento.deleta(id, res)
    })
}