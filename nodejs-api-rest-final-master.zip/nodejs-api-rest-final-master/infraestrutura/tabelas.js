//Criar Tabledas chamando função conexao com o banco
class Tabelas {
    init(conexao) {
        this.conexao = conexao

        this.criarAtendimentos()
    }

//Criar tabela Atendimentos se não existir com suas colunas conforme passado abaixo
    criarAtendimentos() {
        const sql = 'CREATE TABLE IF NOT EXISTS Atendimentos (id int NOT NULL AUTO_INCREMENT, cliente varchar(50) NOT NULL, pet varchar(20), servico varchar(20) NOT NULL, data datetime NOT NULL, dataCriacao datetime NOT NULL, status varchar(20) NOT NULL, observacoes text, PRIMARY KEY(id))'
//Retorna informaçãoes se as tabela(as) foram criadas e suas colunas
        this.conexao.query(sql, erro => {
            if(erro) {
                console.log(erro)
            } else {
                console.log('Tabela Atendimentos criada com sucesso')
            }
        })
    }
}

module.exports = new Tabelas